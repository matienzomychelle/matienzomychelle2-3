export interface vehicle {
    codigo :number;
    nome :string;
}